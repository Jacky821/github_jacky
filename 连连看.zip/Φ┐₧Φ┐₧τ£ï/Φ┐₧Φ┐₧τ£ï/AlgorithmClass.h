//
//  AlgorithmClass.h
//  连连看
//
//  Created by ucsmy on 16/7/19.
//  Copyright © 2016年 ucsmy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlgorithmClass : NSObject

@end
